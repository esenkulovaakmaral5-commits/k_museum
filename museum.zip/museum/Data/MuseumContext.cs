﻿using Microsoft.EntityFrameworkCore;
using k_museum.Models;

namespace k_museum.Data
{
    public class MuseumContext : DbContext
    {
        public MuseumContext(DbContextOptions<MuseumContext> options)
            : base(options)
        {
        }

        public DbSet<User> Users { get; set; }
        public DbSet<Author> Authors { get; set; }
        public DbSet<Exhibit> Exhibits { get; set; }
        public DbSet<Category> Categories { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            // Настройка таблицы Users
            modelBuilder.Entity<User>().ToTable("Users");

            // Настройка таблицы Authors
            modelBuilder.Entity<Author>().ToTable("Authors");

            // Настройка таблицы Exhibits
            modelBuilder.Entity<Exhibit>().ToTable("Exhibits");

            // Настройка таблицы Categories
            modelBuilder.Entity<Category>().ToTable("Categories");

            // Настройка связей (если они есть в базе)
            modelBuilder.Entity<Author>()
                .HasMany(a => a.Exhibits)
                .WithOne(e => e.Author)
                .HasForeignKey(e => e.AuthorId);

            modelBuilder.Entity<Exhibit>()
                .HasOne(e => e.Category)
                .WithMany(c => c.Exhibits)
                .HasForeignKey(e => e.CategoryId);
        }
    }
}