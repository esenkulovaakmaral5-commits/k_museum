using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace k_museum.Views.Admin
{
    public class ExhibitsModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
