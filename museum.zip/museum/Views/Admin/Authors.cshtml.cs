using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace k_museum.Views.Admin
{
    public class AuthorsModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
