using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace k_museum.Views.Admin
{
    public class EditExhibitModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
