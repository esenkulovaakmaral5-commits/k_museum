using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace k_museum.Views.Admin
{
    public class CreateAuthorModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
