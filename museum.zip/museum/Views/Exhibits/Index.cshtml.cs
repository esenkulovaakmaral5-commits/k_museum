using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace k_museum.Views.Exhibits
{
    public class IndexModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
