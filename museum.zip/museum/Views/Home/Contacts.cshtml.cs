using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace k_museum.Views.Home
{
    public class ContactsModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
