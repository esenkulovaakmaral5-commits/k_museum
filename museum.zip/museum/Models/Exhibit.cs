﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace k_museum.Models
{
    [Table("Exhibits")] // Обратите внимание на название таблицы с заглавной буквы
    public class Exhibit
    {
        [Key]
        [Column("id")] // Название столбца в базе
        public int Id { get; set; }

        [Display(Name = "Название")]
        [Column("name")] // Совпадает с базой
        public string? Name { get; set; }

        [Display(Name = "Автор")]
        [Column("author_id")] // Совпадает с базой
        public int? AuthorId { get; set; }

        [Display(Name = "Категория")]
        [Column("category_id")] // Совпадает с базой
        public int? CategoryId { get; set; }

        [Display(Name = "Дата создания")]
        [DataType(DataType.Date)]
        [Column("creation_date")] // Совпадает с базой
        public DateTime? CreationDate { get; set; }

        [Display(Name = "Описание")]
        [Column("description")] // Совпадает с базой
        public string? Description { get; set; }

        [Display(Name = "Тип контента")]
        [Column("content_type")] // Совпадает с базой
        public string? ContentType { get; set; }

        [Display(Name = "Превью")]
        [Column("content_preview")] // Совпадает с базой
        public string? ContentPreview { get; set; }

        [Display(Name = "Изображение")]
        [Column("ExhibitImage")] // Совпадает с базой
        public string? ExhibitImage { get; set; }

        [Display(Name = "Документ")]
        [Column("DocumentPath")] // Совпадает с базой
        public string? DocumentPath { get; set; }

        [Display(Name = "Полный текст")]
        [Column("HasFullContent")] // Совпадает с базой
        public bool? HasFullContent { get; set; }

        // Навигационные свойства
        [ForeignKey("AuthorId")]
        public virtual Author? Author { get; set; }

        [ForeignKey("CategoryId")]
        public virtual Category? Category { get; set; }

        // Метод для получения пути к изображению
        public string GetImagePath()
        {
            if (!string.IsNullOrEmpty(ExhibitImage))
            {
                if (ExhibitImage.StartsWith("http"))
                    return ExhibitImage;

                if (ContentType == "IMG" || string.IsNullOrEmpty(ContentType))
                    return $"/images/exhibits/{ExhibitImage}";
                else if (ContentType == "SCU")
                    return $"/images/sculptures/{ExhibitImage}";
            }
            return "/images/no-image.png";
        }

        // Метод для получения пути к документу
        public string? GetDocumentPath()
        {
            if (!string.IsNullOrEmpty(DocumentPath))
            {
                return $"/documents/exhibits/{DocumentPath}";
            }
            return null;
        }

        // Проверка типов
        public bool IsImage() => ContentType == "IMG" || string.IsNullOrEmpty(ContentType);
        public bool IsSculpture() => ContentType == "SCU";
        public bool IsText() => ContentType == "TXT";

        // Метод для года
        public int? GetYear()
        {
            return CreationDate?.Year;
        }
    }
}