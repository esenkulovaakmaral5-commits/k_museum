﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace k_museum.Models
{
    [Table("Authors")] // Обратите внимание на название таблицы с заглавной буквы
    public class Author
    {
        [Key]
        [Column("id")] // Название столбца в базе
        public int Id { get; set; }

        [Display(Name = "Полное имя")]
        [Column("FullName")] // Совпадает с базой
        public string? FullName { get; set; }

        [Display(Name = "Страна")]
        [Column("Country")] // Совпадает с базой
        public string? Country { get; set; }

        [Display(Name = "Биография")]
        [Column("Biography")] // Совпадает с базой
        public string? Biography { get; set; }

        [Display(Name = "Изображение")]
        [Column("AuthorImage")] // Совпадает с базой
        public string? AuthorImage { get; set; }

        [Display(Name = "Годы жизни")]
        [Column("LifeYears")] // Совпадает с базой
        public string? LifeYears { get; set; }

        [Display(Name = "Основные работы")]
        [Column("MajorWorks")] // Совпадает с базой
        public string? MajorWorks { get; set; }

        [Display(Name = "Направление")]
        [Column("ArtMovement")] // Совпадает с базой
        public string? ArtMovement { get; set; }

        [Display(Name = "Категория")]
        [Column("CategoryId")] // Совпадает с базой
        public int? CategoryId { get; set; }

        // Навигационные свойства
        [ForeignKey("CategoryId")]
        public virtual Category? Category { get; set; }

        public virtual ICollection<Exhibit> Exhibits { get; set; } = new List<Exhibit>();

        // Метод для получения пути к изображению
        public string GetImagePath()
        {
            if (!string.IsNullOrEmpty(AuthorImage))
            {
                // Проверяем, начинается ли путь с http (внешняя ссылка)
                if (AuthorImage.StartsWith("http"))
                    return AuthorImage;

                // Или файл в папке
                return $"/images/authors/{AuthorImage}";
            }
            return "/images/no-image.png";
        }
    }
}