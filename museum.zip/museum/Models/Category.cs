﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace k_museum.Models
{
    [Table("Categories")] // Обратите внимание на название таблицы с заглавной буквы
    public class Category
    {
        [Key]
        [Column("id")] // Название столбца в базе
        public int Id { get; set; }

        [Display(Name = "Название")]
        [Column("name")] // Совпадает с базой
        public string? Name { get; set; }

        // Навигационные свойства
        public virtual ICollection<Exhibit> Exhibits { get; set; } = new List<Exhibit>();
        public virtual ICollection<Author> Authors { get; set; } = new List<Author>();
    }
}