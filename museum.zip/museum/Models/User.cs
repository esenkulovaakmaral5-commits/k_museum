﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace k_museum.Models
{
    [Table("Users")] // Обратите внимание на название таблицы с заглавной буквы
    public class User
    {
        [Key]
        [Column("id")] // Название столбца в базе
        public int Id { get; set; }

        [Column("UserName")] // Совпадает с базой
        public string? UserName { get; set; }

        [Column("Email")] // Совпадает с базой
        public string? Email { get; set; }

        [Column("PasswordHash")] // Совпадает с базой
        public string? PasswordHash { get; set; }

        [Column("Role")] // Совпадает с базой
        public string? Role { get; set; }

        [Column("CreatedDate")] // Совпадает с базой
        public DateTime? CreatedDate { get; set; }
    }
}