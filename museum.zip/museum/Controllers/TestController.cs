﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using k_museum.Data;

namespace k_museum.Controllers
{
    public class TestDbController : Controller
    {
        private readonly MuseumContext _context;

        public TestDbController(MuseumContext context)
        {
            _context = context;
        }

        public async Task<IActionResult> Index()
        {
            try
            {
                // Простая проверка работы с БД
                var canConnect = await _context.Database.CanConnectAsync();
                ViewBag.CanConnect = canConnect;

                if (canConnect)
                {
                    var categories = await _context.Categories.ToListAsync();
                    ViewBag.Categories = categories;
                }

                return View();
            }
            catch (Exception ex)
            {
                ViewBag.Error = ex.Message;
                return View();
            }
        }
    }
}