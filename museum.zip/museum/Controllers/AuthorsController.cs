﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using k_museum.Data;
using k_museum.Models;

namespace k_museum.Controllers
{
    public class AuthorsController : Controller
    {
        private readonly MuseumContext _context;

        public AuthorsController(MuseumContext context)
        {
            _context = context;
        }

        // GET: /Authors
        public async Task<IActionResult> Index(string? category = null)
        {
            try
            {
                IQueryable<Author> query = _context.Authors
                    .Include(a => a.Category)
                    .Include(a => a.Exhibits)
                    .ThenInclude(e => e.Category);

                // Фильтрация по категории
                if (!string.IsNullOrEmpty(category))
                {
                    query = query.Where(a => a.Category != null && a.Category.Name.Contains(category));
                }

                var authors = await query
                    .OrderBy(a => a.FullName)
                    .ToListAsync();

                ViewBag.CategoryFilter = category;
                return View(authors);
            }
            catch (Exception ex)
            {
                ViewBag.Error = $"Ошибка загрузки авторов: {ex.Message}";
                return View(new List<Author>());
            }
        }

        // GET: /Authors/Details/5
        public async Task<IActionResult> Details(int id)
        {
            try
            {
                var author = await _context.Authors
                    .Include(a => a.Category)
                    .Include(a => a.Exhibits)
                        .ThenInclude(e => e.Category)
                    .FirstOrDefaultAsync(a => a.Id == id);

                if (author == null)
                {
                    return NotFound();
                }

                return View(author);
            }
            catch (Exception ex)
            {
                ViewBag.Error = $"Ошибка загрузки автора: {ex.Message}";
                return View(null);
            }
        }

        // GET: /Authors/Search
        public async Task<IActionResult> Search(string query)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(query))
                {
                    return Json(new { success = false, message = "Пустой запрос" });
                }

                var authors = await _context.Authors
                    .Where(a => a.FullName.Contains(query) ||
                               a.Country.Contains(query) ||
                               a.ArtMovement.Contains(query))
                    .Take(10)
                    .Select(a => new
                    {
                        id = a.Id,
                        name = a.FullName,
                        country = a.Country,
                        image = a.AuthorImage,
                        years = a.LifeYears
                    })
                    .ToListAsync();

                return Json(new { success = true, authors });
            }
            catch (Exception ex)
            {
                return Json(new { success = false, message = ex.Message });
            }
        }
    }
}