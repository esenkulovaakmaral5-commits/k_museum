﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using k_museum.Data;
using k_museum.Models;

namespace k_museum.Controllers
{
    public class ExhibitsController : Controller
    {
        private readonly MuseumContext _context;

        public ExhibitsController(MuseumContext context)
        {
            _context = context;
        }

        // GET: /Exhibits
        public async Task<IActionResult> Index(string? category = null, string? author = null)
        {
            try
            {
                IQueryable<Exhibit> query = _context.Exhibits
                    .Include(e => e.Author)
                    .Include(e => e.Category);

                // Фильтрация по категории
                if (!string.IsNullOrEmpty(category) && int.TryParse(category, out int categoryId))
                {
                    query = query.Where(e => e.CategoryId == categoryId);
                }

                // Фильтрация по автору
                if (!string.IsNullOrEmpty(author) && int.TryParse(author, out int authorId))
                {
                    query = query.Where(e => e.AuthorId == authorId);
                }

                var exhibits = await query
                    .OrderByDescending(e => e.CreationDate)
                    .ToListAsync();

                ViewBag.Categories = await _context.Categories.ToListAsync();
                ViewBag.Authors = await _context.Authors.ToListAsync();
                ViewBag.SelectedCategory = category;
                ViewBag.SelectedAuthor = author;

                return View(exhibits);
            }
            catch (Exception ex)
            {
                ViewBag.Error = $"Ошибка загрузки экспонатов: {ex.Message}";
                return View(new List<Exhibit>());
            }
        }

        // GET: /Exhibits/Details/5
        public async Task<IActionResult> Details(int id)
        {
            try
            {
                var exhibit = await _context.Exhibits
                    .Include(e => e.Author)
                    .Include(e => e.Category)
                    .FirstOrDefaultAsync(e => e.Id == id);

                if (exhibit == null)
                {
                    return NotFound();
                }

                // Рекомендуемые экспонаты
                var relatedExhibits = await _context.Exhibits
                    .Where(e => e.Id != id &&
                               (e.AuthorId == exhibit.AuthorId || e.CategoryId == exhibit.CategoryId))
                    .Take(3)
                    .Include(e => e.Author)
                    .ToListAsync();

                ViewBag.RelatedExhibits = relatedExhibits;

                return View(exhibit);
            }
            catch (Exception ex)
            {
                ViewBag.Error = $"Ошибка загрузки экспоната: {ex.Message}";
                return View(null);
            }
        }

        // GET: /Exhibits/Search
        public async Task<IActionResult> Search(string query)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(query))
                {
                    return Json(new { success = false, message = "Пустой запрос" });
                }

                var exhibits = await _context.Exhibits
                    .Where(e => e.Name.Contains(query) ||
                               e.Description.Contains(query))
                    .Take(10)
                    .Include(e => e.Author)
                    .Select(e => new
                    {
                        id = e.Id,
                        name = e.Name,
                        author = e.Author != null ? e.Author.FullName : "Неизвестен",
                        year = e.GetYear(),
                        image = e.GetImagePath(),
                        type = e.ContentType
                    })
                    .ToListAsync();

                return Json(new { success = true, exhibits });
            }
            catch (Exception ex)
            {
                return Json(new { success = false, message = ex.Message });
            }
        }
    }
}