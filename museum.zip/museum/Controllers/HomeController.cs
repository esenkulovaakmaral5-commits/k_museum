using k_museum.Data;
using k_museum.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace k_museum.Controllers
{
    public class HomeController : Controller
    {
        private readonly MuseumContext _context;
        private readonly IWebHostEnvironment _hostingEnvironment;

        public HomeController(MuseumContext context, IWebHostEnvironment hostingEnvironment)
        {
            _context = context;
            _hostingEnvironment = hostingEnvironment;
        }

        public async Task<IActionResult> Index()
        {
            try
            {
                var stats = new
                {
                    TotalExhibits = await _context.Exhibits.CountAsync(),
                    TotalAuthors = await _context.Authors.CountAsync(),
                    TotalCategories = await _context.Categories.CountAsync(),
                    RecentExhibits = await _context.Exhibits
                        .Include(e => e.Author)
                        .Include(e => e.Category)
                        .OrderByDescending(e => e.CreationDate)
                        .Take(6)
                        .ToListAsync()
                };

                ViewBag.Stats = stats;
                return View();
            }
            catch (Exception ex)
            {
                ViewBag.Error = ex.Message;
                return View();
            }
        }

        public async Task<IActionResult> Category()
        {
            try
            {
                var categories = await _context.Categories
                    .Include(c => c.Exhibits)
                    .Include(c => c.Authors)
                    .ToListAsync();

                return View(categories);
            }
            catch (Exception ex)
            {
                ViewBag.Error = ex.Message;
                return View(new List<Category>());
            }
        }

        public IActionResult Contacts()
        {
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new Models.ErrorViewModel());
        }
    }
}