﻿using k_museum.Data;
using k_museum.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;

namespace k_museum.Controllers
{
    [Authorize]
    public class AdminController : Controller
    {
        private readonly MuseumContext _context;
        private readonly IWebHostEnvironment _hostingEnvironment;

        public AdminController(MuseumContext context, IWebHostEnvironment hostingEnvironment)
        {
            _context = context;
            _hostingEnvironment = hostingEnvironment;
        }

        // GET: /Admin/Dashboard
        public async Task<IActionResult> Dashboard()
        {
            try
            {
                var stats = new
                {
                    TotalExhibits = await _context.Exhibits.CountAsync(),
                    TotalAuthors = await _context.Authors.CountAsync(),
                    TotalCategories = await _context.Categories.CountAsync(),
                    RecentExhibits = await _context.Exhibits
                        .Include(e => e.Author)
                        .OrderByDescending(e => e.CreationDate)
                        .Take(5)
                        .ToListAsync(),
                    RecentAuthors = await _context.Authors
                        .OrderByDescending(a => a.Id)
                        .Take(5)
                        .ToListAsync()
                };

                ViewBag.Stats = stats;
                return View();
            }
            catch (Exception ex)
            {
                ViewBag.Error = ex.Message;
                return View();
            }
        }

        #region Авторы

        // GET: /Admin/Authors
        public async Task<IActionResult> Authors()
        {
            try
            {
                var authors = await _context.Authors
                    .Include(a => a.Exhibits)
                    .Include(a => a.Category)
                    .OrderBy(a => a.FullName)
                    .ToListAsync();

                return View(authors);
            }
            catch (Exception ex)
            {
                ViewBag.Error = ex.Message;
                return View(new List<Author>());
            }
        }

        // GET: /Admin/CreateAuthor
        public IActionResult CreateAuthor()
        {
            ViewBag.Categories = new SelectList(_context.Categories, "Id", "Name");
            return View();
        }

        // POST: /Admin/CreateAuthor
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> CreateAuthor(Author author, IFormFile? imageFile)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (imageFile != null && imageFile.Length > 0)
                    {
                        var uploadsFolder = Path.Combine(_hostingEnvironment.WebRootPath, "images", "authors");
                        Directory.CreateDirectory(uploadsFolder);

                        var fileName = Guid.NewGuid().ToString() + Path.GetExtension(imageFile.FileName);
                        var filePath = Path.Combine(uploadsFolder, fileName);

                        using (var stream = new FileStream(filePath, FileMode.Create))
                        {
                            await imageFile.CopyToAsync(stream);
                        }

                        author.AuthorImage = fileName;
                    }

                    _context.Authors.Add(author);
                    await _context.SaveChangesAsync();

                    TempData["SuccessMessage"] = $"Автор '{author.FullName}' успешно добавлен!";
                    return RedirectToAction("Authors");
                }

                ViewBag.Categories = new SelectList(_context.Categories, "Id", "Name", author.CategoryId);
                return View(author);
            }
            catch (Exception ex)
            {
                ModelState.AddModelError("", $"Ошибка при сохранении: {ex.Message}");
                ViewBag.Categories = new SelectList(_context.Categories, "Id", "Name", author.CategoryId);
                return View(author);
            }
        }

        // GET: /Admin/EditAuthor/5
        public async Task<IActionResult> EditAuthor(int id)
        {
            try
            {
                var author = await _context.Authors.FindAsync(id);
                if (author == null)
                {
                    return NotFound();
                }

                ViewBag.Categories = new SelectList(_context.Categories, "Id", "Name", author.CategoryId);
                return View(author);
            }
            catch (Exception ex)
            {
                TempData["ErrorMessage"] = $"Ошибка загрузки: {ex.Message}";
                return RedirectToAction("Authors");
            }
        }

        // POST: /Admin/EditAuthor/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> EditAuthor(int id, Author author, IFormFile? imageFile)
        {
            try
            {
                if (id != author.Id)
                {
                    return NotFound();
                }

                if (ModelState.IsValid)
                {
                    var existingAuthor = await _context.Authors.FindAsync(id);
                    if (existingAuthor == null)
                    {
                        return NotFound();
                    }

                    if (imageFile != null && imageFile.Length > 0)
                    {
                        var uploadsFolder = Path.Combine(_hostingEnvironment.WebRootPath, "images", "authors");
                        Directory.CreateDirectory(uploadsFolder);

                        if (!string.IsNullOrEmpty(existingAuthor.AuthorImage))
                        {
                            var oldFilePath = Path.Combine(uploadsFolder, existingAuthor.AuthorImage);
                            if (System.IO.File.Exists(oldFilePath))
                            {
                                System.IO.File.Delete(oldFilePath);
                            }
                        }

                        var fileName = Guid.NewGuid().ToString() + Path.GetExtension(imageFile.FileName);
                        var filePath = Path.Combine(uploadsFolder, fileName);

                        using (var stream = new FileStream(filePath, FileMode.Create))
                        {
                            await imageFile.CopyToAsync(stream);
                        }

                        existingAuthor.AuthorImage = fileName;
                    }

                    existingAuthor.FullName = author.FullName;
                    existingAuthor.Country = author.Country;
                    existingAuthor.LifeYears = author.LifeYears;
                    existingAuthor.Biography = author.Biography;
                    existingAuthor.MajorWorks = author.MajorWorks;
                    existingAuthor.ArtMovement = author.ArtMovement;
                    existingAuthor.CategoryId = author.CategoryId;

                    _context.Update(existingAuthor);
                    await _context.SaveChangesAsync();

                    TempData["SuccessMessage"] = $"Автор '{author.FullName}' успешно обновлен!";
                    return RedirectToAction("Authors");
                }

                ViewBag.Categories = new SelectList(_context.Categories, "Id", "Name", author.CategoryId);
                return View(author);
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!AuthorExists(author.Id))
                {
                    return NotFound();
                }
                throw;
            }
            catch (Exception ex)
            {
                ModelState.AddModelError("", $"Ошибка при обновлении: {ex.Message}");
                ViewBag.Categories = new SelectList(_context.Categories, "Id", "Name", author.CategoryId);
                return View(author);
            }
        }

        // POST: /Admin/DeleteAuthor/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteAuthor(int id)
        {
            try
            {
                var author = await _context.Authors
                    .Include(a => a.Exhibits)
                    .FirstOrDefaultAsync(a => a.Id == id);

                if (author == null)
                {
                    return NotFound();
                }

                if (author.Exhibits.Any())
                {
                    TempData["ErrorMessage"] = $"Нельзя удалить автора '{author.FullName}', так как у него есть работы!";
                    return RedirectToAction("Authors");
                }

                if (!string.IsNullOrEmpty(author.AuthorImage))
                {
                    var imagePath = Path.Combine(_hostingEnvironment.WebRootPath, "images", "authors", author.AuthorImage);
                    if (System.IO.File.Exists(imagePath))
                    {
                        System.IO.File.Delete(imagePath);
                    }
                }

                _context.Authors.Remove(author);
                await _context.SaveChangesAsync();

                TempData["SuccessMessage"] = $"Автор '{author.FullName}' успешно удален!";
                return RedirectToAction("Authors");
            }
            catch (Exception ex)
            {
                TempData["ErrorMessage"] = $"Ошибка при удалении: {ex.Message}";
                return RedirectToAction("Authors");
            }
        }

        private bool AuthorExists(int id)
        {
            return _context.Authors.Any(e => e.Id == id);
        }

        #endregion

        #region Экспонаты

        // GET: /Admin/Exhibits
        public async Task<IActionResult> Exhibits()
        {
            try
            {
                var exhibits = await _context.Exhibits
                    .Include(e => e.Author)
                    .Include(e => e.Category)
                    .OrderByDescending(e => e.CreationDate)
                    .ToListAsync();

                return View(exhibits);
            }
            catch (Exception ex)
            {
                ViewBag.Error = ex.Message;
                return View(new List<Exhibit>());
            }
        }

        // GET: /Admin/CreateExhibit
        public IActionResult CreateExhibit()
        {
            ViewBag.Authors = new SelectList(_context.Authors, "Id", "FullName");
            ViewBag.Categories = new SelectList(_context.Categories, "Id", "Name");
            ViewBag.ContentTypes = new List<SelectListItem>
            {
                new SelectListItem { Value = "IMG", Text = "Картина/Изображение" },
                new SelectListItem { Value = "SCU", Text = "Скульптура" },
                new SelectListItem { Value = "TXT", Text = "Текстовый документ" }
            };
            return View();
        }

        // POST: /Admin/CreateExhibit
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> CreateExhibit(Exhibit exhibit, IFormFile? imageFile, IFormFile? documentFile)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (imageFile != null && imageFile.Length > 0)
                    {
                        string folderName = exhibit.ContentType switch
                        {
                            "IMG" => "exhibits",
                            "SCU" => "sculptures",
                            _ => "exhibits"
                        };

                        var uploadsFolder = Path.Combine(_hostingEnvironment.WebRootPath, "images", folderName);
                        Directory.CreateDirectory(uploadsFolder);

                        var fileName = Guid.NewGuid().ToString() + Path.GetExtension(imageFile.FileName);
                        var filePath = Path.Combine(uploadsFolder, fileName);

                        using (var stream = new FileStream(filePath, FileMode.Create))
                        {
                            await imageFile.CopyToAsync(stream);
                        }

                        exhibit.ExhibitImage = fileName;
                    }

                    if (documentFile != null && documentFile.Length > 0 && exhibit.ContentType == "TXT")
                    {
                        var uploadsFolder = Path.Combine(_hostingEnvironment.WebRootPath, "documents", "exhibits");
                        Directory.CreateDirectory(uploadsFolder);

                        var fileName = Guid.NewGuid().ToString() + Path.GetExtension(documentFile.FileName);
                        var filePath = Path.Combine(uploadsFolder, fileName);

                        using (var stream = new FileStream(filePath, FileMode.Create))
                        {
                            await documentFile.CopyToAsync(stream);
                        }

                        exhibit.DocumentPath = fileName;
                        exhibit.HasFullContent = true;
                    }

                    _context.Exhibits.Add(exhibit);
                    await _context.SaveChangesAsync();

                    TempData["SuccessMessage"] = $"Экспонат '{exhibit.Name}' успешно добавлен!";
                    return RedirectToAction("Exhibits");
                }

                ViewBag.Authors = new SelectList(_context.Authors, "Id", "FullName", exhibit.AuthorId);
                ViewBag.Categories = new SelectList(_context.Categories, "Id", "Name", exhibit.CategoryId);
                ViewBag.ContentTypes = new List<SelectListItem>
                {
                    new SelectListItem { Value = "IMG", Text = "Картина/Изображение", Selected = exhibit.ContentType == "IMG" },
                    new SelectListItem { Value = "SCU", Text = "Скульптура", Selected = exhibit.ContentType == "SCU" },
                    new SelectListItem { Value = "TXT", Text = "Текстовый документ", Selected = exhibit.ContentType == "TXT" }
                };
                return View(exhibit);
            }
            catch (Exception ex)
            {
                ModelState.AddModelError("", $"Ошибка при сохранении: {ex.Message}");
                ViewBag.Authors = new SelectList(_context.Authors, "Id", "FullName", exhibit.AuthorId);
                ViewBag.Categories = new SelectList(_context.Categories, "Id", "Name", exhibit.CategoryId);
                ViewBag.ContentTypes = new List<SelectListItem>
                {
                    new SelectListItem { Value = "IMG", Text = "Картина/Изображение", Selected = exhibit.ContentType == "IMG" },
                    new SelectListItem { Value = "SCU", Text = "Скульптура", Selected = exhibit.ContentType == "SCU" },
                    new SelectListItem { Value = "TXT", Text = "Текстовый документ", Selected = exhibit.ContentType == "TXT" }
                };
                return View(exhibit);
            }
        }

        // GET: /Admin/EditExhibit/5
        public async Task<IActionResult> EditExhibit(int id)
        {
            try
            {
                var exhibit = await _context.Exhibits
                    .Include(e => e.Author)
                    .Include(e => e.Category)
                    .FirstOrDefaultAsync(e => e.Id == id);

                if (exhibit == null)
                {
                    return NotFound();
                }

                ViewBag.Authors = new SelectList(_context.Authors, "Id", "FullName", exhibit.AuthorId);
                ViewBag.Categories = new SelectList(_context.Categories, "Id", "Name", exhibit.CategoryId);
                ViewBag.ContentTypes = new List<SelectListItem>
                {
                    new SelectListItem { Value = "IMG", Text = "Картина/Изображение", Selected = exhibit.ContentType == "IMG" },
                    new SelectListItem { Value = "SCU", Text = "Скульптура", Selected = exhibit.ContentType == "SCU" },
                    new SelectListItem { Value = "TXT", Text = "Текстовый документ", Selected = exhibit.ContentType == "TXT" }
                };

                return View(exhibit);
            }
            catch (Exception ex)
            {
                TempData["ErrorMessage"] = $"Ошибка загрузки: {ex.Message}";
                return RedirectToAction("Exhibits");
            }
        }

        // POST: /Admin/EditExhibit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> EditExhibit(int id, Exhibit exhibit, IFormFile? imageFile, IFormFile? documentFile)
        {
            try
            {
                if (id != exhibit.Id)
                {
                    return NotFound();
                }

                if (ModelState.IsValid)
                {
                    var existingExhibit = await _context.Exhibits.FindAsync(id);
                    if (existingExhibit == null)
                    {
                        return NotFound();
                    }

                    if (imageFile != null && imageFile.Length > 0)
                    {
                        string folderName = exhibit.ContentType switch
                        {
                            "IMG" => "exhibits",
                            "SCU" => "sculptures",
                            _ => "exhibits"
                        };

                        var uploadsFolder = Path.Combine(_hostingEnvironment.WebRootPath, "images", folderName);
                        Directory.CreateDirectory(uploadsFolder);

                        if (!string.IsNullOrEmpty(existingExhibit.ExhibitImage))
                        {
                            var oldFolderName = existingExhibit.ContentType switch
                            {
                                "IMG" => "exhibits",
                                "SCU" => "sculptures",
                                _ => "exhibits"
                            };

                            var oldFilePath = Path.Combine(_hostingEnvironment.WebRootPath, "images", oldFolderName, existingExhibit.ExhibitImage);
                            if (System.IO.File.Exists(oldFilePath))
                            {
                                System.IO.File.Delete(oldFilePath);
                            }
                        }

                        var fileName = Guid.NewGuid().ToString() + Path.GetExtension(imageFile.FileName);
                        var filePath = Path.Combine(uploadsFolder, fileName);

                        using (var stream = new FileStream(filePath, FileMode.Create))
                        {
                            await imageFile.CopyToAsync(stream);
                        }

                        existingExhibit.ExhibitImage = fileName;
                    }

                    if (documentFile != null && documentFile.Length > 0 && exhibit.ContentType == "TXT")
                    {
                        var uploadsFolder = Path.Combine(_hostingEnvironment.WebRootPath, "documents", "exhibits");
                        Directory.CreateDirectory(uploadsFolder);

                        if (!string.IsNullOrEmpty(existingExhibit.DocumentPath))
                        {
                            var oldFilePath = Path.Combine(uploadsFolder, existingExhibit.DocumentPath);
                            if (System.IO.File.Exists(oldFilePath))
                            {
                                System.IO.File.Delete(oldFilePath);
                            }
                        }

                        var fileName = Guid.NewGuid().ToString() + Path.GetExtension(documentFile.FileName);
                        var filePath = Path.Combine(uploadsFolder, fileName);

                        using (var stream = new FileStream(filePath, FileMode.Create))
                        {
                            await documentFile.CopyToAsync(stream);
                        }

                        existingExhibit.DocumentPath = fileName;
                        existingExhibit.HasFullContent = true;
                    }

                    existingExhibit.Name = exhibit.Name;
                    existingExhibit.Description = exhibit.Description;
                    existingExhibit.CreationDate = exhibit.CreationDate;
                    existingExhibit.ContentType = exhibit.ContentType;
                    existingExhibit.ContentPreview = exhibit.ContentPreview;
                    existingExhibit.AuthorId = exhibit.AuthorId;
                    existingExhibit.CategoryId = exhibit.CategoryId;

                    _context.Update(existingExhibit);
                    await _context.SaveChangesAsync();

                    TempData["SuccessMessage"] = $"Экспонат '{exhibit.Name}' успешно обновлен!";
                    return RedirectToAction("Exhibits");
                }

                ViewBag.Authors = new SelectList(_context.Authors, "Id", "FullName", exhibit.AuthorId);
                ViewBag.Categories = new SelectList(_context.Categories, "Id", "Name", exhibit.CategoryId);
                ViewBag.ContentTypes = new List<SelectListItem>
                {
                    new SelectListItem { Value = "IMG", Text = "Картина/Изображение", Selected = exhibit.ContentType == "IMG" },
                    new SelectListItem { Value = "SCU", Text = "Скульптура", Selected = exhibit.ContentType == "SCU" },
                    new SelectListItem { Value = "TXT", Text = "Текстовый документ", Selected = exhibit.ContentType == "TXT" }
                };
                return View(exhibit);
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!ExhibitExists(exhibit.Id))
                {
                    return NotFound();
                }
                throw;
            }
            catch (Exception ex)
            {
                ModelState.AddModelError("", $"Ошибка при обновлении: {ex.Message}");
                ViewBag.Authors = new SelectList(_context.Authors, "Id", "FullName", exhibit.AuthorId);
                ViewBag.Categories = new SelectList(_context.Categories, "Id", "Name", exhibit.CategoryId);
                ViewBag.ContentTypes = new List<SelectListItem>
                {
                    new SelectListItem { Value = "IMG", Text = "Картина/Изображение", Selected = exhibit.ContentType == "IMG" },
                    new SelectListItem { Value = "SCU", Text = "Скульптура", Selected = exhibit.ContentType == "SCU" },
                    new SelectListItem { Value = "TXT", Text = "Текстовый документ", Selected = exhibit.ContentType == "TXT" }
                };
                return View(exhibit);
            }
        }

        // POST: /Admin/DeleteExhibit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteExhibit(int id)
        {
            try
            {
                var exhibit = await _context.Exhibits.FindAsync(id);
                if (exhibit == null)
                {
                    return NotFound();
                }

                if (!string.IsNullOrEmpty(exhibit.ExhibitImage))
                {
                    string folderName = exhibit.ContentType switch
                    {
                        "IMG" => "exhibits",
                        "SCU" => "sculptures",
                        _ => "exhibits"
                    };

                    var imagePath = Path.Combine(_hostingEnvironment.WebRootPath, "images", folderName, exhibit.ExhibitImage);
                    if (System.IO.File.Exists(imagePath))
                    {
                        System.IO.File.Delete(imagePath);
                    }
                }

                if (!string.IsNullOrEmpty(exhibit.DocumentPath))
                {
                    var docPath = Path.Combine(_hostingEnvironment.WebRootPath, "documents", "exhibits", exhibit.DocumentPath);
                    if (System.IO.File.Exists(docPath))
                    {
                        System.IO.File.Delete(docPath);
                    }
                }

                _context.Exhibits.Remove(exhibit);
                await _context.SaveChangesAsync();

                TempData["SuccessMessage"] = $"Экспонат '{exhibit.Name}' успешно удален!";
                return RedirectToAction("Exhibits");
            }
            catch (Exception ex)
            {
                TempData["ErrorMessage"] = $"Ошибка при удалении: {ex.Message}";
                return RedirectToAction("Exhibits");
            }
        }

        private bool ExhibitExists(int id)
        {
            return _context.Exhibits.Any(e => e.Id == id);
        }

        #endregion

        #region Категории

        // GET: /Admin/Categories
        public async Task<IActionResult> Categories()
        {
            try
            {
                var categories = await _context.Categories
                    .Include(c => c.Exhibits)
                    .Include(c => c.Authors)
                    .ToListAsync();

                return View(categories);
            }
            catch (Exception ex)
            {
                ViewBag.Error = ex.Message;
                return View(new List<Category>());
            }
        }

        // GET: /Admin/CreateCategory
        public IActionResult CreateCategory()
        {
            return View();
        }

        // POST: /Admin/CreateCategory
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> CreateCategory(Category category)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    _context.Categories.Add(category);
                    await _context.SaveChangesAsync();

                    TempData["SuccessMessage"] = $"Категория '{category.Name}' успешно добавлена!";
                    return RedirectToAction("Categories");
                }
                return View(category);
            }
            catch (Exception ex)
            {
                ModelState.AddModelError("", $"Ошибка при сохранении: {ex.Message}");
                return View(category);
            }
        }

        // POST: /Admin/DeleteCategory/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteCategory(int id)
        {
            try
            {
                var category = await _context.Categories
                    .Include(c => c.Exhibits)
                    .Include(c => c.Authors)
                    .FirstOrDefaultAsync(c => c.Id == id);

                if (category == null)
                {
                    return NotFound();
                }

                if (category.Exhibits.Any() || category.Authors.Any())
                {
                    TempData["ErrorMessage"] = $"Нельзя удалить категорию '{category.Name}', так как в ней есть экспонаты или авторы!";
                    return RedirectToAction("Categories");
                }

                _context.Categories.Remove(category);
                await _context.SaveChangesAsync();

                TempData["SuccessMessage"] = $"Категория '{category.Name}' успешно удалена!";
                return RedirectToAction("Categories");
            }
            catch (Exception ex)
            {
                TempData["ErrorMessage"] = $"Ошибка при удалении: {ex.Message}";
                return RedirectToAction("Categories");
            }
        }

        private bool CategoryExists(int id)
        {
            return _context.Categories.Any(e => e.Id == id);
        }

        #endregion
    }
}